import { forwardRef } from 'react';
import MovieCard from './MovieCard';
import useLocalStorage from '../hooks/useLocalStorage';

const MoviesList = forwardRef(({ movies }, ref) => {
    const [favorites, setFavorites] = useLocalStorage('favorites', []);

    const getIsFavoriteMovie = (movie) => {
        return favorites.some((favorite) => favorite.imdbID === movie.imdbID);
    };

    const handleClick = (newMovie) => {
        const isAlreadyFavoriteMovie = getIsFavoriteMovie(newMovie);
        let updatedFavorites = [];
        if (isAlreadyFavoriteMovie) {
            //remove movie from favorite list
            updatedFavorites = favorites.filter(
                (favorite) => favorite.imdbID !== newMovie.imdbID
            );
        } else {
            // add movie to favorite list
            updatedFavorites = [...favorites, newMovie];
        }
        setFavorites(updatedFavorites);
    };

    return (
        <div className="movie-list">
            {movies?.map((movie, index) => {
                const isFavoriteMovie = getIsFavoriteMovie(movie);
                if (movies.length === index + 1) {
                    return (
                        <MovieCard
                            ref={ref}
                            key={movie.imdbID}
                            movie={movie}
                            handleClick={handleClick}
                            isFavoriteMovie={isFavoriteMovie}
                        />
                    );
                }
                return (
                    <MovieCard
                        key={movie.imdbID}
                        movie={movie}
                        handleClick={handleClick}
                        isFavoriteMovie={isFavoriteMovie}
                    />
                );
            })}
        </div>
    );
});

export default MoviesList;
