import { forwardRef } from 'react';
import { ReactComponent as FavoriteIconRegular } from '../assets/favorite-regular.svg';
import { ReactComponent as FavoriteIconSolid } from '../assets/favorite-solid.svg';

const MovieCard = forwardRef(({ movie, handleClick, isFavoriteMovie }, ref) => {
    const { Title, Poster, Plot } = movie || {};
    return (
        <div className="movie-card" ref={ref}>
            <div className="movie-card__image-wrapper">
                <img src={Poster} alt={Title} />
            </div>
            <div className="movie-card__description">
                <h3>{Title}</h3>
                <p>{Plot}</p>
            </div>
            <div
                className="movie-card__favorite"
                onClick={() => handleClick(movie)}
            >
                {isFavoriteMovie ? (
                    <FavoriteIconSolid className="movie-card__favorite-icon" />
                ) : (
                    <FavoriteIconRegular className="movie-card__favorite-icon" />
                )}
            </div>
        </div>
    );
});

export default MovieCard;
