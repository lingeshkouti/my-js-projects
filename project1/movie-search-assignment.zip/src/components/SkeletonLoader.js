const SkeletonLoader = () => {
    return (
        <div className="movie-list skeleton-container">
            {new Array(8).fill('').map((item, index) => {
                return (
                    <div key={index} className="movie-card">
                        <div className="movie-card__image-wrapper skeleton-image skeleton"></div>
                        <div className="movie-card__description">
                            <div className="skeleton-text"></div>
                            <div className="skeleton skeleton-text"></div>
                            <div className="skeleton skeleton-text"></div>
                            <div className="skeleton skeleton-text"></div>
                            <div className="skeleton skeleton-text"></div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

export default SkeletonLoader;
