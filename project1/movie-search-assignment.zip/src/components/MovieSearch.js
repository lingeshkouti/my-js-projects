import searchIcon from '../assets/searchIcon.svg';

const MovieSearch = ({ value, setValue }) => {
    return (
        <div className="movie-search">
            <img
                src={searchIcon}
                alt="movie search"
                className="movie-search__icon"
            />
            <input
                type="search"
                name="movie-search"
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder="Search Movies"
            />
        </div>
    );
};

export default MovieSearch;
