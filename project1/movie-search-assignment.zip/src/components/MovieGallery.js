import MoviesList from './MoviesList';
import SkeletonLoader from './SkeletonLoader';

const MovieGallery = ({ trendingMovies, recentMovies, favorites }) => {
    if (trendingMovies.loading || recentMovies.loading) {
        return <SkeletonLoader />;
    }

    return (
        <div>
            {favorites?.length > 0 && (
                <div>
                    <h2>Favorite movies</h2>
                    <MoviesList movies={favorites} />
                </div>
            )}
            {trendingMovies.data?.length > 0 && (
                <div>
                    <h2>Trending movies</h2>
                    <MoviesList movies={trendingMovies.data} />
                </div>
            )}
            {recentMovies.data?.length > 0 && (
                <div>
                    <h2>Recent movies</h2>
                    <MoviesList movies={recentMovies.data} />
                </div>
            )}
        </div>
    );
};

export default MovieGallery;
