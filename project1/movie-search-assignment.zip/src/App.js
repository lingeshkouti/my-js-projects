import React, { useCallback, useEffect, useState, useRef } from 'react';
import './styles/main.scss';
import MovieSearch from './components/MovieSearch';
import MoviesList from './components/MoviesList';
import useMovieSearch from './hooks/useMovieSearch';
import SkeletonLoader from './components/SkeletonLoader';
import useLocalStorage from './hooks/useLocalStorage';
import useQuery from './hooks/useQuery';
import MovieGallery from './components/MovieGallery';

const TRENDING_MOVIE_URL = 'http://localhost:4000/trending-movies?_limit=8';
const RECENT_MOVIE_URL = 'http://localhost:4000/recent-movies?_limit=8';

const App = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const trendingMovies = useQuery(TRENDING_MOVIE_URL);
    const recentMovies = useQuery(RECENT_MOVIE_URL);
    const [pageNumber, setPageNumber] = useState(1);
    const { loading, error, movies, hasMore } = useMovieSearch(
        searchTerm,
        pageNumber
    );
    const [favorites] = useLocalStorage('favorites', []);

    useEffect(() => {
        setPageNumber(1);
    }, [searchTerm]);

    const observer = useRef();
    const getLastElementRef = useCallback(
        (node) => {
            if (loading) return;
            if (observer.current) observer.current.disconnect();
            observer.current = new IntersectionObserver((entries) => {
                if (entries[0].isIntersecting && hasMore) {
                    setPageNumber((prev) => prev + 1);
                }
            });
            if (node) observer.current.observe(node);
        },
        [hasMore, loading]
    );

    return (
        <div className="movie-search-app">
            <h1 className="movie-search-app__heading">Movie Search App</h1>
            <MovieSearch value={searchTerm} setValue={setSearchTerm} />
            {movies?.length > 0 && (
                <MoviesList movies={movies} ref={getLastElementRef} />
            )}
            {loading && <SkeletonLoader />}
            {error && <div>Error occurred!</div>}
            {!loading && searchTerm && movies.length === 0 && (
                <div>No search results</div>
            )}
            {!searchTerm && (
                <MovieGallery
                    trendingMovies={trendingMovies}
                    favorites={favorites}
                    recentMovies={recentMovies}
                />
            )}
        </div>
    );
};

export default App;
