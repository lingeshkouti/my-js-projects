import { useEffect, useState } from 'react';
import useDebounce from './useDebounce';

const useMovieSearch = (searchTerm, pageNumber) => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(false);
    const [movies, setMovies] = useState([]);
    const [hasMore, setHasMore] = useState(false);
    const debouncedSearchTerm = useDebounce(searchTerm);

    useEffect(() => {
        setMovies([]);
    }, [debouncedSearchTerm]);

    useEffect(() => {
        async function fetchMovies() {
            setLoading(true);
            try {
                const response = await fetch(
                    `http://localhost:4000/movies?Title_like=${debouncedSearchTerm}&_limit=12&_page=${pageNumber}`
                );
                const data = await response.json();
                const totalRecords = response.headers.get('x-total-count');
                setMovies((prev) => {
                    const updatedMovies = [...prev, ...data];
                    const hasMoreRecords = updatedMovies?.length < totalRecords;
                    setHasMore(hasMoreRecords);
                    return [...prev, ...data];
                });
            } catch (error) {
                setError(error);
            } finally {
                setLoading(false);
            }
        }

        if (debouncedSearchTerm) {
            fetchMovies();
        }
    }, [debouncedSearchTerm, pageNumber]);

    return { loading, error, movies, hasMore };
};

export default useMovieSearch;
